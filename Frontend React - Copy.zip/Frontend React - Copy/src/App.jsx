// src/App.jsx
import React from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Home from './components/Home';
import VehicleList from './components/VehicleList';
import AdminVehiclePage from './components/AdminVehiclePage';
import ReviewPage from './components/ReviewPage'; // New Review Page
import PrivateRoute from './components/PrivateRoute';
import Header from './components/Header';
import VehicleDetailPage from './components/VehicleDetail';
import VehicleComparisonPage from './components/CompareVehicles';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const App = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const token = localStorage.getItem("token");
  const showHeader = location.pathname !== "/login" && token;

  const handleLogout = () => {
    localStorage.removeItem("token");
    sessionStorage.clear();
    navigate("/login");
  };

  return (
    <>
      {showHeader && <Header onLogout={handleLogout} />}

      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route
          path="/home"
          element={
            <PrivateRoute>
              <Home />
            </PrivateRoute>
          }
        />

        <Route
          path="/vehicles"
          element={
            <PrivateRoute>
              <VehicleList />
            </PrivateRoute>
          }
        />
         <Route path="/compare-vehicles" element={<PrivateRoute>
          <VehicleComparisonPage />
          </PrivateRoute>
          } />
        <Route
          path="/admin-vehicles"
          element={
            <PrivateRoute requiredRole="ADMIN">
              <AdminVehiclePage />
            </PrivateRoute>
          }
        />

        {/* New route for the review page */}
        <Route
          path="/vehicle/:id/reviews"
          element={
            <PrivateRoute>
              <ReviewPage />
            </PrivateRoute>
          }
        />
        <Route path="/vehicle/:id" element={
           <PrivateRoute>
            <VehicleDetailPage />
            </PrivateRoute>} />

       
        <Route
          path="/reviews" 
          element={
            <PrivateRoute>
              <ReviewPage /> {/* This component will render the review details */}
              <ToastContainer position="top-right" autoClose={3000} />
            </PrivateRoute>
          }
        />

        <Route path="*" element={<PrivateRoute><Home /></PrivateRoute>} />
      </Routes>
    </>
  );
};

export default App;
