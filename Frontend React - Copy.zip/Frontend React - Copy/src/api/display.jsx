// src/api/display.js

export const fetchVehicles = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8085/display/vehicles', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
  
      if (!response.ok) {
        throw new Error('Failed to fetch vehicles');
      }
  
      const data = await response.json();
      return data; // Return the vehicle data here
    } catch (error) {
      console.error('Error fetching vehicles:', error);
      throw error;
    }
  };
  