// src/api/vehicleApi.js
import axios from 'axios';

const API_URL = 'http://localhost:8085/vehicles';  // Update to your vehicle service URL

// Fetch all vehicles
export const fetchVehicles = async () => {
  const token = localStorage.getItem('token');  // Retrieve the token from localStorage
  if (!token) {
    console.error('No token found in localStorage');
    throw new Error('No token found');
  }

  try {
    const response = await axios.get(`${API_URL}/getAllVehicles`, {
      headers: {
        Authorization: `Bearer ${token}`,  // Include the token in the Authorization header
      },
    });
    return response.data; // List of vehicles
  } catch (error) {
    console.error('Error fetching vehicles:', error);
    throw error;
  }
};

// Add a new vehicle
export const addVehicle = async (vehicleData) => {
  try {
    const response = await axios.post(`${API_URL}`, vehicleData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });
    return response.data; // Created vehicle
  } catch (error) {
    console.error('Error adding vehicle:', error);
    throw error;
  }
};

// Update an existing vehicle
export const updateVehicle = async (id, vehicleData) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, vehicleData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });
    return response.data; // Updated vehicle
  } catch (error) {
    console.error('Error updating vehicle:', error);
    throw error;
  }
};

// Delete a vehicle
export const deleteVehicle = async (id) => {
  try {
    await axios.delete(`${API_URL}/${id}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });
  } catch (error) {
    console.error('Error deleting vehicle:', error);
    throw error;
  }
};
