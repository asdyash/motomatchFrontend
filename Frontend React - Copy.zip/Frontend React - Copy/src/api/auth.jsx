// src/api/auth.js
import axios from 'axios';
import * as jwt_decode from 'jwt-decode';

const API_URL = 'http://localhost:8085/auth'; // API Gateway base URL


export const getUserRole = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;
  const decoded = jwtDecode(token);
  return decoded.role || null;
};
export const login = async (username, password) => {
  try {
    const response = await axios.post(`${API_URL}/login`, { username, password },
      {
        headers: { 'Content-Type': 'application/json' },
        responseType: 'text'
      });
    // console.log(response.data); // Log the response for debugging
    return response.data; // { token: 'JWT' }
  } catch (error) {
    console.error('Login failed', error);
    throw error;
  }
};

export const register = async (username, email,password,role) => {
  try {
    const response = await axios.post(`${API_URL}/register`, { username, email,password ,role});
    return response.data;
  } catch (error) {
    console.error('Registration failed', error);
    throw error;
  }
};
