import axios from 'axios';

const API_URL = 'http://localhost:8085/reviews'; // Update with your actual API URL


// Function to fetch reviews for a specific vehicle using vehicle ID
export const getReviewsByVehicle = async (vehicleId) => {
  const token = localStorage.getItem('token');

  if (!token) {
    throw new Error('No token found in local storage');
  }

  try {
    const response = await axios.get(`${API_URL}/vehicle/${vehicleId}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching reviews:', error.response || error.message);
    throw new Error('Failed to fetch reviews');
  }
};


// Function to submit a review for a vehicle
export const submitReview = async (reviewData) => {
  const token = localStorage.getItem('token');
  // console.log('Token:', token); // Log token for debugging purposes

  if (!token) {
    throw new Error('No token found in local storage');
  }

  try {
    const response = await axios.post(API_URL, reviewData, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error submitting review:', error.response || error.message);
    throw new Error('Failed to submit review');
  }
};
