// src/api/compare.js
import axios from 'axios';

const API_URL = 'http://localhost:8085/compare';

export const compareVehicles = async (vehicle1Id, vehicle2Id) => {
  try {
    const response = await axios.get(`${API_URL}?vehicle1=${vehicle1Id}&vehicle2=${vehicle2Id}`);
    return response.data;
  } catch (error) {
    console.error('Error comparing vehicles', error);
    throw error;
  }
};
