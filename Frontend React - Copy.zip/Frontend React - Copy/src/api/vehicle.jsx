// src/api/vehicle.js
import axios from 'axios';
import { getReviewsByVehicle } from './review';

const API_URL = 'http://localhost:8085/vehicles';

export const getVehicles = async () => {
  try {
    const response = await axios.get(`${API_URL}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching vehicles', error);
    throw error;
  }
};
// Fetch all vehicles
export const getAllVehicles = async () => {
  try {
    const response = await axios.get(`${API_URL}/getAllVehicles`);
    return response.data;  // Assuming the response contains an array of vehicles
  } catch (error) {
    console.error('Error fetching vehicles', error);
    throw error;
  }
};

export const getVehicleById = async (id) => {
  try {
    const response = await axios.get(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching vehicle details', error);
    throw error;
  }
};
