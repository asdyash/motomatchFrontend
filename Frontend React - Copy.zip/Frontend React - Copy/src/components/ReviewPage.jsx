import React, { useState, useEffect } from 'react';
import { getReviewsByVehicle } from '../api/review';
import ReviewForm from './ReviewForm';
import ReviewList from './ReviewList';

const ReviewPage = () => {
  const [reviews, setReviews] = useState([]);
  const [selectedVehicleName, setSelectedVehicleName] = useState('');

  useEffect(() => {
    const fetchReviews = async () => {
      if (selectedVehicleName) {
        try {
          const data = await getReviewsByVehicle(selectedVehicleName);
          setReviews(data);
        } catch (err) {
          console.error('Failed to fetch reviews:', err);
        }
      }
    };
    fetchReviews();
  }, [selectedVehicleName]);

  return (
    <div>
      <ReviewForm setSelectedVehicleName={setSelectedVehicleName} />
      {/* <ReviewList reviews={reviews} /> */}
    </div>
  );
};

export default ReviewPage;
