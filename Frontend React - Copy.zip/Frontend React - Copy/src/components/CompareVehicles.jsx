import React, { useState, useEffect } from 'react';
import { getAllVehicles } from '../api/vehicle';

const VehicleComparisonPage = () => {
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicles, setSelectedVehicles] = useState([]);

  // Fetch all vehicles for comparison
  const fetchVehicles = async () => {
    try {
      const data = await getAllVehicles();
      setVehicles(data);
    } catch (error) {
      console.error('Error fetching vehicles:', error);
    }
  };

  // Handle vehicle selection for comparison
  const handleVehicleSelect = (vehicle) => {
    if (selectedVehicles.some(v => v.id === vehicle.id)) {
      setSelectedVehicles(selectedVehicles.filter(v => v.id !== vehicle.id)); // Deselect
    } else if (selectedVehicles.length < 3) { // Limit selection to 3 vehicles
      setSelectedVehicles([...selectedVehicles, vehicle]); // Select
    } else {
      alert('You can only compare up to 3 vehicles at a time.');
    }
  };

  // Display comparison of selected vehicles
  const renderComparison = () => {
    if (selectedVehicles.length > 1) {
      return (
        <div className="comparison-table mt-5">
          <h3 className="text-center mb-4">Vehicle Comparison</h3>
          <div className="table-responsive">
            <table className="table table-bordered table-hover table-striped">
              <thead className="table-dark">
                <tr>
                  <th>Vehicle</th>
                  <th>Brand</th>
                  <th>Model</th>
                  <th>Year</th>
                  <th>Price</th>
                  <th>Engine Specs</th>
                  <th>Fuel Type</th>
                  <th>Description</th>
                  {/* <th>Rating</th> */}
                </tr>
              </thead>
              <tbody>
                {selectedVehicles.map(vehicle => (
                  <tr key={vehicle.id}>
                    <td>{vehicle.name}</td>
                    <td>{vehicle.brand}</td>
                    <td>{vehicle.model}</td>
                    <td>{vehicle.year}</td>
                    <td>₹{vehicle.price.toLocaleString()}</td>
                    <td>{vehicle.engineSpecs}</td>
                    <td>{vehicle.fuelType}</td>
                    <td>{vehicle.description}</td>
                    {/* <td>{vehicle.rating || 'N/A'}</td> */}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      );
    } else {
      return <p className="text-center mt-4">Select at least two vehicles to compare.</p>;
    }
  };

  useEffect(() => {
    fetchVehicles();
  }, []);

  return (
    <div className="container">
      <h2 className="my-5 text-center">Compare Vehicles</h2>

      <div className="vehicle-selection mb-5">
        <div className="row">
          {vehicles.map((vehicle) => (
            <div
              key={vehicle.id}
              className={`col-md-4 col-sm-6 mb-4 vehicle-card ${selectedVehicles.some(v => v.id === vehicle.id) ? 'selected' : ''}`}
              onClick={() => handleVehicleSelect(vehicle)}
              style={{ cursor: 'pointer' }}
            >
              <div className="card p-3 shadow-sm border-0">
                <img src={vehicle.imageUrl || '/default-image.jpg'} alt={vehicle.name} className="card-img-top" />
                <div className="card-body text-center">
                  <h5 className="card-title">{vehicle.name}</h5>
                  <p>{vehicle.model} ({vehicle.year})</p>
                  <p><strong>₹{vehicle.price.toLocaleString()}</strong></p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {renderComparison()}

      {/* Embedded CSS */}
      <style jsx>{`
        /* Vehicle Card Hover Effect */
        .vehicle-card {
          border-radius: 12px;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .vehicle-card:hover {
          transform: translateY(-5px);
          box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
        }

        .vehicle-card.selected {
          background-color: #007bff;
          color: white;
          border: 2px solid #0056b3; /* Blue border for selected card */
        }

        .vehicle-card.selected .card-body {
          background-color: #0056b3; /* Darker background for the card body */
        }

        .vehicle-card.selected .card-title,
        .vehicle-card.selected p {
          color: white;
        }

        /* Custom Table Styling */
        .table th, .table td {
          text-align: center;
          vertical-align: middle;
          font-size: 14px;
        }

        .table td {
          padding: 10px;
        }

        .table-hover tbody tr:hover {
          background-color: #f9f9f9;
        }

        .table-responsive {
          margin-top: 30px;
        }

        /* Adjust Image Size for Vehicle Cards */
        .card-img-top {
          height: 200px;
          object-fit: cover;
          border-radius: 8px;
        }

        /* Page Spacing and Padding */
        .container {
          padding: 0 15px;
        }

        h2, .vehicle-selection, .comparison-table {
          margin-top: 20px;
        }

        .vehicle-selection {
          margin-bottom: 40px;
        }
      `}</style>
    </div>
  );
};

export default VehicleComparisonPage;
