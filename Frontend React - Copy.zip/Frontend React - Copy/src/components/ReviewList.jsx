import React from 'react';

const ReviewList = ({ reviews }) => {
  return (
    <div className="container mt-4">
      <h4>Reviews</h4>
      {reviews.length > 0 ? (
        <ul className="list-group">
          {reviews.map(review => (
            <li key={review.id} className="list-group-item">
              <strong>{review.username}</strong> – <em>{review.rating}★</em>
              <p>{review.reviewText}</p>
              <small>{new Date(review.createdAt).toLocaleDateString()}</small>
            </li>
          ))}
        </ul>
      ) : (
        <p>No reviews yet for this vehicle.</p>
      )}
    </div>
  );
};

export default ReviewList;
