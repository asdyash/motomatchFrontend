// src/components/Login.jsx

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../api/auth'; // Ensure this function handles the login API request

const Login = ({ setAuthToken }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const token = await login(username, password); // Get JWT token directly
      if (!token) throw new Error('Token not found in response');

      localStorage.setItem('token', token); // Store token in localStorage for persistence
      if (typeof setAuthToken === 'function') {
        setAuthToken(token); // Optional, if using context/prop
      }

      navigate('/home'); // Redirect to home page upon successful login
    } catch (err) {
      console.error('Login failed:', err.message);
      setError('Invalid credentials'); // Display error message
    }
  };

  return (
    <div style={containerStyles}>
      <div style={formContainerStyles}>
        <h2 style={headingStyles}>Login</h2>
        
        {error && <p style={errorStyles}>{error}</p>}

        <form onSubmit={handleLogin} style={formStyles}>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={inputStyles}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={inputStyles}
            required
          />
          <button type="submit" style={buttonStyles}>Login</button>
        </form>
        
        <p style={redirectTextStyle}>
          Don't have an account? <span onClick={() => navigate('/register')} style={linkStyle}>Register here</span>
        </p>
      </div>
    </div>
  );
};

// Styles for the login page
const containerStyles = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  minHeight: '100vh',
  backgroundColor: '#f0f4f8',
};

const formContainerStyles = {
  backgroundColor: 'white',
  padding: '3rem',
  borderRadius: '10px',
  boxShadow: '0px 10px 20px rgba(0, 0, 0, 0.1)',
  width: '100%',
  maxWidth: '450px',
  textAlign: 'center',
  transition: 'all 0.3s ease',
};

const headingStyles = {
  fontSize: '2rem',
  fontWeight: '600',
  marginBottom: '1.5rem',
  color: '#2c3e50',
  letterSpacing: '0.5px',
};

const formStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '1.5rem',
  alignItems: 'center',
};

const inputStyles = {
  width: '100%',
  padding: '0.8rem',
  fontSize: '1rem',
  marginBottom: '1rem',
  borderRadius: '8px',
  border: '1px solid #ddd',
  outline: 'none',
  transition: 'border-color 0.3s',
};

const inputFocusStyles = {
  border: '1px solid #3498db',
};

const buttonStyles = {
  width: '100%',
  padding: '0.9rem',
  fontSize: '1.1rem',
  backgroundColor: '#3498db',
  color: 'white',
  border: 'none',
  borderRadius: '8px',
  cursor: 'pointer',
  transition: 'background-color 0.3s',
};

const buttonHoverStyles = {
  backgroundColor: '#2980b9',
};

const errorStyles = {
  color: '#e74c3c',
  marginBottom: '1.5rem',
  fontSize: '1rem',
  fontWeight: 'bold',
};

const redirectTextStyle = {
  fontSize: '1rem',
  marginTop: '1rem',
};

const linkStyle = {
  color: '#3498db',
  cursor: 'pointer',
  fontWeight: 'bold',
  textDecoration: 'underline',
  transition: 'color 0.3s',
};

export default Login;
