import React, { useState, useEffect } from 'react';
import { submitReview } from '../api/review';
import { getAllVehicles } from '../api/vehicle';
import { jwtDecode } from 'jwt-decode';
import {  getReviewsByVehicle } from '../api/review';
import { toast } from 'react-toastify';
const ReviewForm = () => {
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicleId, setSelectedVehicleId] = useState('');
  const [selectedVehicleName, setSelectedVehicleName] = useState('');
  const [rating, setRating] = useState(1);
  const [reviewText, setReviewText] = useState('');
  const [error, setError] = useState('');
  const token = localStorage.getItem('token');

  let username = '';
  if (token) {
    const decoded = jwtDecode(token);
    username = decoded.sub || decoded.username;
  }

  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const data = await getAllVehicles();
        setVehicles(data);
      } catch (err) {
        console.error('Failed to load vehicles:', err);
      }
    };
    fetchVehicles();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!selectedVehicleId || !rating || !reviewText.trim() || !username) {
      setError('All fields are required.');
      return;
    }
  
    const reviewPayload = {
      vehicleId: selectedVehicleId,
      username,
      rating,
      reviewText,
    };
  
    try {
      await submitReview(reviewPayload);
      toast.success('✅ Review submitted successfully!');
      setRating(1);
      setReviewText('');
      setError('');
    } catch (err) {
      toast.error('❌ Failed to submit review. Please try again.');
    }
  };
  
  

  return (
    <div className="container mt-5">
      <h2>Submit Review</h2>
      {error && <div className="alert alert-danger">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Select Vehicle</label>
          <select
            className="form-select"
            value={selectedVehicleId}
            onChange={(e) => {
              const vehicle = vehicles.find(v => v.id === e.target.value);
              setSelectedVehicleId(vehicle.id);
              setSelectedVehicleName(vehicle.name);
            }}
          >
            <option value="">-- Choose a vehicle --</option>
            {vehicles.map(vehicle => (
              <option key={vehicle.id} value={vehicle.id}>
                {vehicle.name}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">Rating</label>
          <select
            className="form-select"
            value={rating}
            onChange={(e) => setRating(parseInt(e.target.value))}
          >
            {[1, 2, 3, 4, 5].map(num => (
              <option key={num} value={num}>
                {num} - {['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'][num - 1]}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">Review</label>
          <textarea
            className="form-control"
            rows="4"
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            maxLength="500"
            placeholder="Write your review"
          />
        </div>

        <button type="submit" className="btn btn-primary">
          Submit Review
        </button>
      </form>
    </div>
  );
};

export default ReviewForm;
