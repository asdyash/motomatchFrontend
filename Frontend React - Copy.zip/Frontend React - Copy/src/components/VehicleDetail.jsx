// src/components/VehicleDetailPage.jsx
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getVehicleById } from '../api/vehicle';
import { getReviewsByVehicle } from '../api/review';
import ReviewList from './ReviewList';

const VehicleDetailPage = () => {
  const { id } = useParams();
  const [vehicle, setVehicle] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        const vehicleData = await getVehicleById(id);
        setVehicle(vehicleData);

        const reviewData = await getReviewsByVehicle(id);
        setReviews(reviewData);
      } catch (err) {
        setError('Failed to load vehicle details or reviews.');
      }
    };

    fetchDetails();
  }, [id]);

  if (error) return <p className="text-danger">{error}</p>;
  if (!vehicle) return <p>Loading vehicle details...</p>;

  return (
    <div className="container my-5">
      <div className="row">
        {/* Vehicle Image */}
        <div className="col-md-6 d-flex align-items-center justify-content-center mb-4">
  {vehicle.imageUrl && (
    <img
      src={vehicle.imageUrl}
      alt={vehicle.name}
      className="img-fluid rounded shadow"
      style={{ maxHeight: '480px', objectFit: 'cover', marginTop: '30px', width: '100%',height: '350px' }}
    />
  )}
</div>


        {/* Vehicle Details */}
        <div className="col-md-6">
        <h2 className="mb-4" style={{ fontWeight: 'bold', fontSize: '2.5rem', color: '#0d6efd' }}>
  {vehicle.name}
</h2>

          <p className="text-muted mb-4">{vehicle.description}</p>

          <ul className="list-group list-group-flush mb-4">
            <li className="list-group-item"><strong>Brand:</strong> {vehicle.brand}</li>
            <li className="list-group-item"><strong>Model:</strong> {vehicle.model}</li>
            <li className="list-group-item"><strong>Year:</strong> {vehicle.year}</li>
            <li className="list-group-item"><strong>Type:</strong> {vehicle.type}</li>
            <li className="list-group-item"><strong>Engine:</strong> {vehicle.engineSpecs}</li>
            <li className="list-group-item"><strong>Fuel Type:</strong> {vehicle.fuelType}</li>
            <li className="list-group-item"><strong>Price:</strong> ₹{vehicle.price.toLocaleString()}</li>
          </ul>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="mt-5">
        <h3 className="mb-4">Customer Reviews</h3>
        <ReviewList reviews={reviews} />
      </div>
    </div>
  );
};

export default VehicleDetailPage;
