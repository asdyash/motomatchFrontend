// src/components/Header.jsx
import React from "react";
import { Navbar, Nav, Container, Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";

const Header = ({ onLogout }) => {
  const token = localStorage.getItem("token");
  let userRole = null;

  if (token) {
    try {
      const decodedToken = JSON.parse(atob(token.split(".")[1]));
      userRole = decodedToken?.role;
    } catch (e) {
      console.error("Invalid token:", e);
    }
  }

  return (
    <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand href="/">MotoMatch</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbar-nav" />
        <Navbar.Collapse id="navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="/vehicles">Vehicles</Nav.Link>
            <Nav.Link href="/compare-vehicles">Compare Vehicles</Nav.Link>
            {/* Conditionally render the Reviews link if the user is logged in */}
            {userRole === "USER" && ( <Nav.Link href="/reviews">Reviews</Nav.Link>)}

            {/* Admin link to the Vehicle Admin page, visible only for admins */}
            {userRole === "ADMIN" && (
              <Nav.Link as={Link} to="/admin-vehicles">Vehicle Admin</Nav.Link>
            )}
          </Nav>
          <Button variant="outline-light" onClick={onLogout}>
            Logout
          </Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
