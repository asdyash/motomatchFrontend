// src/components/Home.jsx

import React, { useEffect, useState } from "react";
import { fetchVehicles } from "../api/display";
import { useNavigate } from "react-router-dom";
import Header from "./Header";

const Home = () => {
  const [vehicles, setVehicles] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const getVehicles = async () => {
      try {
        const vehiclesData = await fetchVehicles();
        setVehicles(vehiclesData);
      } catch (err) {
        setError('Failed to load vehicles');
      }
    };
    getVehicles();
  }, []);

  return (
    <div>
      {/* <Header /> */}
      <h2 style={{ textAlign: "center", marginTop: "2rem", fontSize: "2.5rem", fontWeight: "bold" }}>
        Explore Our Vehicles
      </h2>

      {error && <p className="text-danger text-center">{error}</p>}

      <div style={{
        padding: "2rem",
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
        gap: "2rem",
        justifyItems: "center"
      }}>
        {vehicles.length > 0 ? (
          vehicles.map((vehicle) => (
            <div
              key={vehicle.id}
              onClick={() => navigate(`/vehicle/${vehicle.id}`)}
              style={{
                cursor: "pointer",
                border: "1px solid #ddd",
                borderRadius: "16px",
                overflow: "hidden",
                width: "100%",
                maxWidth: "320px",
                boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                transition: "transform 0.3s, box-shadow 0.3s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "scale(1.03)";
                e.currentTarget.style.boxShadow = "0 6px 16px rgba(0,0,0,0.2)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "scale(1)";
                e.currentTarget.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
              }}
            >
              {vehicle.imageUrl && (
                <img
                  src={vehicle.imageUrl}
                  alt={vehicle.name}
                  style={{
                    width: "100%",
                    height: "200px",
                    objectFit: "cover",
                  }}
                />
              )}
              <div style={{ padding: "1rem" }}>
                <h4 style={{ fontWeight: "bold", marginBottom: "0.5rem" }}>{vehicle.name}</h4>
                <p style={{ color: "#555", marginBottom: "0.3rem" }}>{vehicle.model}</p>
                <p style={{ fontWeight: "bold", color: "#007bff" }}>₹{vehicle.price.toLocaleString()}</p>
              </div>
            </div>
          ))
        ) : (
          <p>No vehicles available.</p>
        )}
      </div>
    </div>
  );
};

export default Home;
