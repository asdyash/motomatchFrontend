import React, { useState, useEffect } from 'react';
import { fetchVehicles, addVehicle, updateVehicle, deleteVehicle } from '../api/vehicleApi';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Header';

const AdminVehiclePage = () => {
  const [vehicles, setVehicles] = useState([]);
  const [newVehicle, setNewVehicle] = useState({
    name: '', brand: '', model: '', year: '', description: '',
    type: '', engineSpecs: '', fuelType: '', price: '', imageUrl: ''
  });
  const [editVehicle, setEditVehicle] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const getVehicles = async () => {
      try {
        const vehicleData = await fetchVehicles();
        setVehicles(vehicleData);
      } catch (err) {
        setError('Error fetching vehicles');
      }
    };
    getVehicles();
  }, []);

  const handleAddVehicle = async () => {
    try {
      const createdVehicle = await addVehicle(newVehicle);
      setVehicles([...vehicles, createdVehicle]);
      setNewVehicle({
        name: '', brand: '', model: '', year: '', description: '',
        type: '', engineSpecs: '', fuelType: '', price: '', imageUrl: ''
      });
    } catch (err) {
      setError('Error adding vehicle');
    }
  };

  const handleEditVehicle = async () => {
    try {
      const updatedVehicle = await updateVehicle(editVehicle.id, editVehicle);
      setVehicles(vehicles.map(v => (v.id === updatedVehicle.id ? updatedVehicle : v)));
      setEditVehicle(null);
    } catch (err) {
      setError('Error updating vehicle');
    }
  };

  const handleDeleteVehicle = async (id) => {
    try {
      await deleteVehicle(id);
      setVehicles(vehicles.filter(v => v.id !== id));
    } catch (err) {
      setError('Error deleting vehicle');
    }
  };

  return (
    <div>
      <div className="container mt-4">
        <h2>Admin Vehicle Management</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        {/* Add New Vehicle Form */}
        <div className="card my-4">
          <div className="card-body">
            <h4 className="card-title">Add New Vehicle</h4>
            <div className="form-group">
              <input className="form-control mb-3" type="text" placeholder="Name" value={newVehicle.name} onChange={e => setNewVehicle({ ...newVehicle, name: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Brand" value={newVehicle.brand} onChange={e => setNewVehicle({ ...newVehicle, brand: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Model" value={newVehicle.model} onChange={e => setNewVehicle({ ...newVehicle, model: e.target.value })} />
              <input className="form-control mb-3" type="number" placeholder="Year" value={newVehicle.year} onChange={e => setNewVehicle({ ...newVehicle, year: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Description" value={newVehicle.description} onChange={e => setNewVehicle({ ...newVehicle, description: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Type" value={newVehicle.type} onChange={e => setNewVehicle({ ...newVehicle, type: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Engine Specs" value={newVehicle.engineSpecs} onChange={e => setNewVehicle({ ...newVehicle, engineSpecs: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Fuel Type" value={newVehicle.fuelType} onChange={e => setNewVehicle({ ...newVehicle, fuelType: e.target.value })} />
              <input className="form-control mb-3" type="number" placeholder="Price" value={newVehicle.price} onChange={e => setNewVehicle({ ...newVehicle, price: e.target.value })} />
              <input className="form-control mb-3" type="text" placeholder="Image URL" value={newVehicle.imageUrl} onChange={e => setNewVehicle({ ...newVehicle, imageUrl: e.target.value })} />
              <button className="btn btn-primary" onClick={handleAddVehicle}>Add Vehicle</button>
            </div>
          </div>
        </div>

        {/* Vehicle List Table */}
        <div className="card">
          <div className="card-body">
            <h4 className="card-title">Manage Vehicles</h4>
            <div className="table-responsive">
              <table className="table table-striped table-bordered">
                <thead className="table-dark">
                  <tr>
                    <th>Name</th>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Year</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Engine Specs</th>
                    <th>Fuel Type</th>
                    <th>Price</th>
                    <th>Image URL</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {vehicles.map(vehicle => (
                    <tr key={vehicle.id}>
                      <td>{vehicle.name}</td>
                      <td>{vehicle.brand}</td>
                      <td>{vehicle.model}</td>
                      <td>{vehicle.year}</td>
                      <td>{vehicle.description}</td>
                      <td>{vehicle.type}</td>
                      <td>{vehicle.engineSpecs}</td>
                      <td>{vehicle.fuelType}</td>
                      <td>₹{vehicle.price.toLocaleString()}</td>
                      <td>{vehicle.imageUrl}</td>
                      <td>
                        <button className="btn btn-warning btn-sm me-2" onClick={() => setEditVehicle(vehicle)}>Edit</button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDeleteVehicle(vehicle.id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Edit Vehicle Section */}
        {editVehicle && (
          <div className="card my-4">
            <div className="card-body">
              <h4 className="card-title mb-4">Edit Vehicle</h4>
              <div className="form-group">
                <label>Name</label>
                <input className="form-control mb-3" value={editVehicle.name} onChange={e => setEditVehicle({ ...editVehicle, name: e.target.value })} />
                <label>Brand</label>
                <input className="form-control mb-3" value={editVehicle.brand} onChange={e => setEditVehicle({ ...editVehicle, brand: e.target.value })} />
                <label>Model</label>
                <input className="form-control mb-3" value={editVehicle.model} onChange={e => setEditVehicle({ ...editVehicle, model: e.target.value })} />
                <label>Year</label>
                <input type="number" className="form-control mb-3" value={editVehicle.year} onChange={e => setEditVehicle({ ...editVehicle, year: e.target.value })} />
                <label>Description</label>
                <textarea className="form-control mb-3" rows="3" value={editVehicle.description} onChange={e => setEditVehicle({ ...editVehicle, description: e.target.value })} />
                <label>Type</label>
                <input className="form-control mb-3" value={editVehicle.type} onChange={e => setEditVehicle({ ...editVehicle, type: e.target.value })} />
                <label>Engine Specs</label>
                <input className="form-control mb-3" value={editVehicle.engineSpecs} onChange={e => setEditVehicle({ ...editVehicle, engineSpecs: e.target.value })} />
                <label>Fuel Type</label>
                <input className="form-control mb-3" value={editVehicle.fuelType} onChange={e => setEditVehicle({ ...editVehicle, fuelType: e.target.value })} />
                <label>Price</label>
                <input type="number" step="0.01" className="form-control mb-3" value={editVehicle.price} onChange={e => setEditVehicle({ ...editVehicle, price: e.target.value })} />
                <label>Image URL</label>
                <input className="form-control mb-3" value={editVehicle.imageUrl} onChange={e => setEditVehicle({ ...editVehicle, imageUrl: e.target.value })} />
                <div className="d-flex justify-content-end">
                  <button className="btn btn-primary me-2" onClick={handleEditVehicle}>Save Changes</button>
                  <button className="btn btn-secondary" onClick={() => setEditVehicle(null)}>Cancel</button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default AdminVehiclePage;
