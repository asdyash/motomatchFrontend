import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAllVehicles } from '../api/vehicle';

const VehicleList = () => {
  const [vehicles, setVehicles] = useState([]);

  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const data = await getAllVehicles();
        setVehicles(data);
      } catch (error) {
        console.error('Error fetching vehicles:', error);
      }
    };

    fetchVehicles();
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Available Vehicles</h2>
      {vehicles.length === 0 ? (
        <p className="text-center text-muted">No vehicles available at the moment.</p>
      ) : (
        <div className="row">
          {vehicles.map((vehicle) => (
            <div key={vehicle.id} className="col-md-4 mb-4">
              <div className="card h-100 shadow-sm">
                {vehicle.imageUrl && (
                  <img
                    src={vehicle.imageUrl}
                    className="card-img-top"
                    alt={vehicle.name}
                    style={{ height: '200px', objectFit: 'cover' }}
                  />
                )}
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{vehicle.name}</h5>
                  <p className="card-text text-truncate" title={vehicle.description}>
                    {vehicle.description}
                  </p>
                  <p className="card-text mt-auto">
                    <strong>₹{vehicle.price}</strong>
                  </p>
                  <Link to={`/vehicle/${vehicle.id}`} className="btn btn-primary btn-sm mt-2">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default VehicleList;
